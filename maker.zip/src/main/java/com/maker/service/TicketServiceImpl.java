package com.maker.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.maker.domain.TicketVO;
import com.maker.mapper.TicketMapper;

import lombok.RequiredArgsConstructor;
import lombok.ToString;

@RequiredArgsConstructor
@Service
@ToString
public class TicketServiceImpl implements TicketService {
	
	private final TicketMapper mapper;
	
    public void register(TicketVO ticket) {
    	mapper.insert(ticket);
    }
    public List<TicketVO> getList() {
        return mapper.getList();
    }
    public List<Integer> getSeatList(String t_time){
    	return mapper.getSeatList(t_time);
    }
    //티켓 중복 확인
    public String isExistsTicketInfo(String t_time, int sno) {

        String isExists = "false";
        if(mapper.ticketCheck(t_time, sno) > 0) {
        	isExists = "true";
        }
        return isExists;
    }
	@Override
	public TicketVO get(Long tno) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int remove(Long tno) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int findByCno(Long cno) {
		// TODO Auto-generated method stub
		return 0;
	}
}
